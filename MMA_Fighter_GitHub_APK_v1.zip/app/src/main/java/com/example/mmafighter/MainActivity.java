package com.example.mmafighter;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, menu, fight;
    TextView hp, enemyHp, stamina, status, fighterName, enemyName;
    int player=100, enemy=100, stam=100;
    Handler handler=new Handler();

    String[] fighters={"IRON","BULLET","PHANTOM","HUNTER","TITAN","STORM","VIPER","BEAST"};

    public void onCreate(Bundle b){super.onCreate(b); showMenu();}

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setGravity(Gravity.CENTER); t.setPadding(10,10,10,10); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(16); return b;
    }
    void base(LinearLayout l){l.setBackgroundColor(Color.rgb(12,12,16)); l.setPadding(25,20,25,20);}

    void showMenu(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); base(root);
        TextView title=tv("MMA FIGHTER",34); root.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        TextView sub=tv("ANDROID EDITION  •  VERSION 1.0",14); root.addView(sub);
        Button start=btn("▶  НОВЫЙ БОЙ"); root.addView(start,new LinearLayout.LayoutParams(-1,75));
        TextView info=tv("8 бойцов • быстрый аркадный бой • управление на экране",14); root.addView(info,new LinearLayout.LayoutParams(-1,60));
        start.setOnClickListener(v->showFight());
        setContentView(root);
    }

    void showFight(){
        player=100; enemy=100; stam=100;
        fight=new LinearLayout(this); fight.setOrientation(LinearLayout.VERTICAL); base(fight);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        fighterName=tv("IRON",20); enemyName=tv("BULLET",20);
        top.addView(fighterName,new LinearLayout.LayoutParams(0,55,1)); top.addView(enemyName,new LinearLayout.LayoutParams(0,55,1));
        fight.addView(top);
        hp=tv("ТВОЁ HP: 100",18); enemyHp=tv("HP СОПЕРНИКА: 100",18); stamina=tv("ВЫНОСЛИВОСТЬ: 100",15);
        fight.addView(hp); fight.addView(enemyHp); fight.addView(stamina);
        status=tv("БОЙ НАЧАЛСЯ!",22); fight.addView(status,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout controls=new LinearLayout(this);
        String[] moves={"👊 УДАР","🦵 КИК","🛡 БЛОК","↔ УКЛОН"};
        for(String m:moves){
            Button b=btn(m); controls.addView(b,new LinearLayout.LayoutParams(0,80,1));
            b.setOnClickListener(v->action(m));
        }
        fight.addView(controls);
        Button back=btn("В МЕНЮ"); fight.addView(back,new LinearLayout.LayoutParams(-1,55)); back.setOnClickListener(v->showMenu());
        setContentView(fight);
    }

    void action(String move){
        if(player<=0||enemy<=0)return;
        if(stam<10 && !move.contains("БЛОК")){status.setText("Нужно восстановить выносливость!"); return;}
        int dmg=0;
        if(move.contains("УДАР")){dmg=8+(int)(Math.random()*8); stam-=12;}
        else if(move.contains("КИК")){dmg=10+(int)(Math.random()*10); stam-=16;}
        else if(move.contains("УКЛОН")){stam=Math.max(0,stam-8); status.setText("Ты уклонился!"); enemyAttack(true); update(); return;}
        else {stam=Math.min(100,stam+8); status.setText("Ты поставил блок и восстановил дыхание."); enemyAttack(true); update(); return;}
        enemy=Math.max(0,enemy-dmg);
        status.setText(move+"  •  -"+dmg+" HP");
        if(enemy==0){status.setText("🏆 НОКАУТ! ТЫ ПОБЕДИЛ!"); update(); return;}
        enemyAttack(false); update();
    }

    void enemyAttack(boolean avoided){
        if(avoided && Math.random()<0.65){status.setText(status.getText()+"  Соперник промахнулся!"); return;}
        int dmg=5+(int)(Math.random()*11);
        player=Math.max(0,player-dmg);
        if(player==0)status.setText("💀 ТЫ ПРОИГРАЛ — НОКАУТ");
    }
    void update(){
        hp.setText("ТВОЁ HP: "+player);
        enemyHp.setText("HP СОПЕРНИКА: "+enemy);
        stamina.setText("ВЫНОСЛИВОСТЬ: "+stam);
    }
}
